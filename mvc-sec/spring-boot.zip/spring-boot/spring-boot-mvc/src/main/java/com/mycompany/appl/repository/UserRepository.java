package com.mycompany.appl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mycompany.appl.domain.User;

public interface UserRepository extends JpaRepository<User, String> {
}
