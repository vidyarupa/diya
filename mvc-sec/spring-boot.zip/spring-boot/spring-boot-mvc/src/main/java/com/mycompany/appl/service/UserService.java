package com.mycompany.appl.service;

import java.util.List;

import com.mycompany.appl.domain.User;

public interface UserService {

    User save(User user);

    List<User> getList();

}
